SurfStack WAMP
Copyright 2014 Joseph Spurrier

This is the source for the SSWAMP.exe application.
C# .NET 4.0

Licensed under Apache License Version 2.0.
License available in file called LICENSE.txt.